<?php get_header(); ?>
	<div class="post standard-bottom-border">
		<h1>404!</h1>
		<p>Hope you're enjoying the internet's favourite error message! You should probably head on over to the <a href="<?php echo home_url(); ?>">home page</a>.</p>
	</div>
<?php get_footer(); ?>